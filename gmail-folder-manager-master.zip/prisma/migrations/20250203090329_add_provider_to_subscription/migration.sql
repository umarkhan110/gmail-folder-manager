-- AlterTable
ALTER TABLE "UserSubscription" ADD COLUMN     "provider" TEXT;
