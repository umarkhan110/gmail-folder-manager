// "use server"
// import { createGmailWatch } from "@/lib/gmailService";

// async function refreshGmailWatch() {
//     await createGmailWatch();
// }

// setInterval(refreshGmailWatch, 3600000);